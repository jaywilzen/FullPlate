var krms_config ={			
	'ApiUrl':"",		
	'AppTitle':"FULLPLATE",
	'ApiKey' : '',
	'debug': false
};